#' @keywords internal
#' @aliases cli-package
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
