# issue #154 [plain]

    Code
      cli_code("a\nb\nc")
    Message
      a
      b
      c

# issue #154 [ansi]

    Code
      cli_code("a\nb\nc")
    Message
      a
      b
      c

# issue #154 [unicode]

    Code
      cli_code("a\nb\nc")
    Message
      a
      b
      c

# issue #154 [fancy]

    Code
      cli_code("a\nb\nc")
    Message
      a
      b
      c

