library(testthat)
library(magrittr)

test_check("magrittr")
