#ifndef RLANG_INTERNAL_CALL_H
#define RLANG_INTERNAL_CALL_H

#include <rlang.h>

r_obj* rlang_call2(r_obj* fn, r_obj* args, r_obj* ns);


#endif
