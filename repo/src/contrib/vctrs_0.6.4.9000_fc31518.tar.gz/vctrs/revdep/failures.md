# ADAM

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ADAM
* Number of recursive dependencies: 95

Run `revdepcheck::cloud_details(, "ADAM")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# AGread

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/AGread
* Number of recursive dependencies: 91

Run `revdepcheck::cloud_details(, "AGread")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# AMARETTO

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/AMARETTO
* Number of recursive dependencies: 155

Run `revdepcheck::cloud_details(, "AMARETTO")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# amplican

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/amplican
* Number of recursive dependencies: 117

Run `revdepcheck::cloud_details(, "amplican")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# anomalize

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/anomalize
* Number of recursive dependencies: 205

Run `revdepcheck::cloud_details(, "anomalize")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bayesmodels

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/bayesmodels
* Number of recursive dependencies: 261

Run `revdepcheck::cloud_details(, "bayesmodels")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BMTME

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BMTME
* Number of recursive dependencies: 64

Run `revdepcheck::cloud_details(, "BMTME")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# brendaDb

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/brendaDb
* Number of recursive dependencies: 120

Run `revdepcheck::cloud_details(, "brendaDb")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BUSpaRse

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BUSpaRse
* Number of recursive dependencies: 157

Run `revdepcheck::cloud_details(, "BUSpaRse")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cattonum

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cattonum
* Number of recursive dependencies: 79

Run `revdepcheck::cloud_details(, "cattonum")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ceRNAnetsim

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ceRNAnetsim
* Number of recursive dependencies: 100

Run `revdepcheck::cloud_details(, "ceRNAnetsim")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# COMPASS

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/COMPASS
* Number of recursive dependencies: 151

Run `revdepcheck::cloud_details(, "COMPASS")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cort

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cort
* Number of recursive dependencies: 76

Run `revdepcheck::cloud_details(, "cort")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ctDNAtools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ctDNAtools
* Number of recursive dependencies: 144

Run `revdepcheck::cloud_details(, "ctDNAtools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CytoML

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CytoML
* Number of recursive dependencies: 106

Run `revdepcheck::cloud_details(, "CytoML")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# datastructures

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/datastructures
* Number of recursive dependencies: 62

Run `revdepcheck::cloud_details(, "datastructures")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# DeLorean

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/DeLorean
* Number of recursive dependencies: 121

Run `revdepcheck::cloud_details(, "DeLorean")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# DepecheR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/DepecheR
* Number of recursive dependencies: 117

Run `revdepcheck::cloud_details(, "DepecheR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# destiny

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/destiny
* Number of recursive dependencies: 243

Run `revdepcheck::cloud_details(, "destiny")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# DiffBind

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/DiffBind
* Number of recursive dependencies: 159

Run `revdepcheck::cloud_details(, "DiffBind")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# diffman

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/diffman
* Number of recursive dependencies: 126

Run `revdepcheck::cloud_details(, "diffman")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# diffrprojects

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/diffrprojects
* Number of recursive dependencies: 66

Run `revdepcheck::cloud_details(, "diffrprojects")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dynfrail

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/dynfrail
* Number of recursive dependencies: 57

Run `revdepcheck::cloud_details(, "dynfrail")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# epiphy

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/epiphy
* Number of recursive dependencies: 92

Run `revdepcheck::cloud_details(, "epiphy")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# evaluator

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/evaluator
* Number of recursive dependencies: 146

Run `revdepcheck::cloud_details(, "evaluator")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# expstudies

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/expstudies
* Number of recursive dependencies: 60

Run `revdepcheck::cloud_details(, "expstudies")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# fipe

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/fipe
* Number of recursive dependencies: 70

Run `revdepcheck::cloud_details(, "fipe")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# foieGras

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/foieGras
* Number of recursive dependencies: 135

Run `revdepcheck::cloud_details(, "foieGras")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ImputeRobust

<details>

* Version: 1.3-1
* GitHub: NA
* Source code: https://github.com/cran/ImputeRobust
* Date/Publication: 2018-11-30 12:10:03 UTC
* Number of recursive dependencies: 86

Run `revdepcheck::cloud_details(, "ImputeRobust")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/ImputeRobust/new/ImputeRobust.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘ImputeRobust/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘ImputeRobust’ version ‘1.3-1’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘extremevalues’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/ImputeRobust/old/ImputeRobust.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘ImputeRobust/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘ImputeRobust’ version ‘1.3-1’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘extremevalues’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# IsoCorrectoR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/IsoCorrectoR
* Number of recursive dependencies: 71

Run `revdepcheck::cloud_details(, "IsoCorrectoR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# loon.ggplot

<details>

* Version: 1.3.3
* GitHub: https://github.com/great-northern-diver/loon.ggplot
* Source code: https://github.com/cran/loon.ggplot
* Date/Publication: 2022-11-12 22:30:02 UTC
* Number of recursive dependencies: 105

Run `revdepcheck::cloud_details(, "loon.ggplot")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/loon.ggplot/new/loon.ggplot.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘loon.ggplot/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘loon.ggplot’ version ‘1.3.3’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘loon’

Package suggested but not available for checking: ‘zenplots’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/loon.ggplot/old/loon.ggplot.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘loon.ggplot/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘loon.ggplot’ version ‘1.3.3’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘loon’

Package suggested but not available for checking: ‘zenplots’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# loon.shiny

<details>

* Version: 1.0.3
* GitHub: NA
* Source code: https://github.com/cran/loon.shiny
* Date/Publication: 2022-10-08 15:30:02 UTC
* Number of recursive dependencies: 136

Run `revdepcheck::cloud_details(, "loon.shiny")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/loon.shiny/new/loon.shiny.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘loon.shiny/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘loon.shiny’ version ‘1.0.3’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages required but not available: 'loon', 'loon.ggplot'

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/loon.shiny/old/loon.shiny.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘loon.shiny/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘loon.shiny’ version ‘1.0.3’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages required but not available: 'loon', 'loon.ggplot'

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# mafs

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/mafs
* Number of recursive dependencies: 90

Run `revdepcheck::cloud_details(, "mafs")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MarketMatching

<details>

* Version: 1.2.0
* GitHub: NA
* Source code: https://github.com/cran/MarketMatching
* Date/Publication: 2021-01-08 20:10:02 UTC
* Number of recursive dependencies: 74

Run `revdepcheck::cloud_details(, "MarketMatching")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/MarketMatching/new/MarketMatching.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘MarketMatching/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘MarketMatching’ version ‘1.2.0’
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages required but not available: 'CausalImpact', 'bsts', 'Boom'

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/MarketMatching/old/MarketMatching.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘MarketMatching/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘MarketMatching’ version ‘1.2.0’
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages required but not available: 'CausalImpact', 'bsts', 'Boom'

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# modeltime.h2o

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/modeltime.h2o
* Number of recursive dependencies: 218

Run `revdepcheck::cloud_details(, "modeltime.h2o")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Platypus

<details>

* Version: 3.4.1
* GitHub: NA
* Source code: https://github.com/cran/Platypus
* Date/Publication: 2022-08-15 07:20:20 UTC
* Number of recursive dependencies: 354

Run `revdepcheck::cloud_details(, "Platypus")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/Platypus/new/Platypus.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘Platypus/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘Platypus’ version ‘3.4.1’
* package encoding: UTF-8
* checking package namespace information ... OK
...
* checking installed files from ‘inst/doc’ ... OK
* checking files in ‘vignettes’ ... OK
* checking examples ... OK
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘PlatypusV3_agedCNS.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 3 WARNINGs, 2 NOTEs





```
### CRAN

```
* using log directory ‘/tmp/workdir/Platypus/old/Platypus.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘Platypus/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘Platypus’ version ‘3.4.1’
* package encoding: UTF-8
* checking package namespace information ... OK
...
* checking installed files from ‘inst/doc’ ... OK
* checking files in ‘vignettes’ ... OK
* checking examples ... OK
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘PlatypusV3_agedCNS.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 3 WARNINGs, 2 NOTEs





```
# SCtools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/SCtools
* Number of recursive dependencies: 93

Run `revdepcheck::cloud_details(, "SCtools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# sknifedatar

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/sknifedatar
* Number of recursive dependencies: 213

Run `revdepcheck::cloud_details(, "sknifedatar")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidyfit

<details>

* Version: 0.6.4
* GitHub: https://github.com/jpfitzinger/tidyfit
* Source code: https://github.com/cran/tidyfit
* Date/Publication: 2023-05-20 15:40:02 UTC
* Number of recursive dependencies: 165

Run `revdepcheck::cloud_details(, "tidyfit")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/tidyfit/new/tidyfit.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘tidyfit/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘tidyfit’ version ‘0.6.4’
* package encoding: UTF-8
* checking package namespace information ... OK
...
  ‘Flowchart.Rmd’ using ‘UTF-8’... OK
  ‘Predicting_Boston_House_Prices.Rmd’ using ‘UTF-8’... OK
  ‘Bootstrapping_Confidence_Intervals.Rmd’ using ‘UTF-8’... OK
  ‘Feature_Selection.Rmd’ using ‘UTF-8’... OK
  ‘Multinomial_Classification.Rmd’ using ‘UTF-8’... OK
  ‘Rolling_Window_Time_Series_Regression.Rmd’ using ‘UTF-8’... OK
  ‘Time-varying_parameters_vs_rolling_windows.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 2 ERRORs, 1 NOTE





```
### CRAN

```
* using log directory ‘/tmp/workdir/tidyfit/old/tidyfit.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘tidyfit/DESCRIPTION’ ... OK
* checking extension type ... Package
* this is package ‘tidyfit’ version ‘0.6.4’
* package encoding: UTF-8
* checking package namespace information ... OK
...
  ‘Flowchart.Rmd’ using ‘UTF-8’... OK
  ‘Predicting_Boston_House_Prices.Rmd’ using ‘UTF-8’... OK
  ‘Bootstrapping_Confidence_Intervals.Rmd’ using ‘UTF-8’... OK
  ‘Feature_Selection.Rmd’ using ‘UTF-8’... OK
  ‘Multinomial_Classification.Rmd’ using ‘UTF-8’... OK
  ‘Rolling_Window_Time_Series_Regression.Rmd’ using ‘UTF-8’... OK
  ‘Time-varying_parameters_vs_rolling_windows.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 2 ERRORs, 1 NOTE





```
# vivid

<details>

* Version: 0.2.7
* GitHub: NA
* Source code: https://github.com/cran/vivid
* Date/Publication: 2023-04-11 13:50:02 UTC
* Number of recursive dependencies: 209

Run `revdepcheck::cloud_details(, "vivid")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/vivid/new/vivid.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘vivid/DESCRIPTION’ ... OK
* this is package ‘vivid’ version ‘0.2.7’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... NOTE
...
* checking installed files from ‘inst/doc’ ... OK
* checking files in ‘vignettes’ ... OK
* checking examples ... OK
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘vividVignette.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 1 NOTE





```
### CRAN

```
* using log directory ‘/tmp/workdir/vivid/old/vivid.Rcheck’
* using R version 4.2.1 (2022-06-23)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘vivid/DESCRIPTION’ ... OK
* this is package ‘vivid’ version ‘0.2.7’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... NOTE
...
* checking installed files from ‘inst/doc’ ... OK
* checking files in ‘vignettes’ ... OK
* checking examples ... OK
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘vividVignette.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 1 NOTE





```
