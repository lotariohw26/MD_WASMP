#ifndef VCTRS_HASH_H
#define VCTRS_HASH_H

#define HASH_MISSING 1

#endif
