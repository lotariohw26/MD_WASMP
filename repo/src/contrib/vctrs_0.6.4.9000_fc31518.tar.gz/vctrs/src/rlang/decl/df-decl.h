static
void init_compact_rownames(r_obj* x, r_ssize n_rows);

static
r_obj* new_compact_rownames(r_ssize n_rows);
