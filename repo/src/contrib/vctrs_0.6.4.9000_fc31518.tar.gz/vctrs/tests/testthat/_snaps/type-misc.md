# `numeric_version` proxy can handle at most 8 components

    Code
      vec_proxy_equal(x)
    Condition
      Error in `vec_proxy_equal()`:
      ! `x` can't contain more than 8 version components.

