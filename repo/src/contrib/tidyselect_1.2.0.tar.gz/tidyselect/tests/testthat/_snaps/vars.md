# generic error message is thrown if `fn` is not supplied

    Code
      peek_vars()
    Condition
      Error:
      ! Selection helpers must be used within a *selecting* function.
      i See <https://tidyselect.r-lib.org/reference/faq-selection-context.html> for details.

---

    Code
      peek_vars()
    Condition
      Error:
      ! Selection helpers must be used within a *selecting* function.
      i See ]8;package = tidyselect:topic = faq-selection-context;ide:help?tidyselect::faq-selection-context]8;; for details.

