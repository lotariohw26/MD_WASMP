static
bool reserve_push_back(struct r_dyn_list_of* p_lof, r_ssize i, void* p_elt);

static
void reserve_move(struct r_dyn_list_of* p_lof, r_ssize i, void* p_elt);
