# Revdeps

## Failed to check (40)

|package        |version |error |warning |note |
|:--------------|:-------|:-----|:-------|:----|
|ADAM           |?       |      |        |     |
|AGread         |?       |      |        |     |
|AMARETTO       |?       |      |        |     |
|amplican       |?       |      |        |     |
|anomalize      |?       |      |        |     |
|bayesmodels    |?       |      |        |     |
|BMTME          |?       |      |        |     |
|brendaDb       |?       |      |        |     |
|BUSpaRse       |?       |      |        |     |
|cattonum       |?       |      |        |     |
|ceRNAnetsim    |?       |      |        |     |
|COMPASS        |?       |      |        |     |
|cort           |?       |      |        |     |
|ctDNAtools     |?       |      |        |     |
|CytoML         |?       |      |        |     |
|datastructures |?       |      |        |     |
|DeLorean       |?       |      |        |     |
|DepecheR       |?       |      |        |     |
|destiny        |?       |      |        |     |
|DiffBind       |?       |      |        |     |
|diffman        |?       |      |        |     |
|diffrprojects  |?       |      |        |     |
|dynfrail       |?       |      |        |     |
|epiphy         |?       |      |        |     |
|evaluator      |?       |      |        |     |
|expstudies     |?       |      |        |     |
|fipe           |?       |      |        |     |
|foieGras       |?       |      |        |     |
|ImputeRobust   |?       |      |        |     |
|IsoCorrectoR   |?       |      |        |     |
|loon.ggplot    |?       |      |        |     |
|loon.shiny     |?       |      |        |     |
|mafs           |?       |      |        |     |
|MarketMatching |?       |      |        |     |
|modeltime.h2o  |?       |      |        |     |
|Platypus       |?       |      |        |     |
|SCtools        |?       |      |        |     |
|sknifedatar    |?       |      |        |     |
|tidyfit        |?       |      |        |     |
|vivid          |?       |      |        |     |

## New problems (2)

|package   |version |error  |warning |note |
|:---------|:-------|:------|:-------|:----|
|[covidcast](problems.md#covidcast)|0.5.0   |__+1__ |        |1    |
|[scGOclust](problems.md#scgoclust)|0.1.0   |__+1__ |        |     |

