#prg <- rep(0,4); rparv <- c(theta=0,phi=0,rho=0); frm <- 2; eqregpar<-c('alpha=k0+k1*g+k2*h'); sf <- 'g' 
#vn <- ManifoldDestiny::recnav[appsel]
#vals <- lapply(seq(1,length(vn)), function(x) get(paste0("app_",x,"_bal")))
#names(vals) <- vn




