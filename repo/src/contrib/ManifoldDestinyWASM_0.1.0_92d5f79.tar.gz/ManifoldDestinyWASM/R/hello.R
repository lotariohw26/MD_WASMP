#' @export hello
hello <- function(x=2,y=2) {
  print("Hello, world!",x+y)
}

